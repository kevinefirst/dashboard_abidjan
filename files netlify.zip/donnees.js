"use strict";

/**
 * DATA ESIGL | Fonction Netlify : récupère les données côté serveur,
 * calcule complétude / promptitude et renvoie un JSON prêt à afficher.
 *
 * Variables d'environnement (à définir dans Netlify, jamais dans le code) :
 *   GSHEET_ID            identifiant du classeur des données (obligatoire)
 *   GSHEET_GID           numéro de l'onglet (défaut : 0)
 *   SITES_SHEET_ID       identifiant du classeur de la liste des sites (facultatif)
 *   SITES_GSHEET_GID     numéro de l'onglet de la liste des sites (défaut : 0)
 */

const COLONNES_SHEET = [
  "region", "code", "facility", "district", "program", "cde_urgente",
  "period", "statut", "user", "date_soumission", "date_autorisation",
  "time_ago", "date_limite", "completude", "promptitude", "couverture",
];
const COLONNES_MINIMUM = 11;

// Liste des sites : 1re colonne = district, 2e = site, 3e (facultative) = région
const COLONNES_SITES = ["district", "facility", "region"];
const COLONNES_SITES_MINIMUM = 2;

const JOUR = 86400000;
const JOUR_LIMITE_DISTRICT = 10;
const JOUR_LIMITE_AUTRES = 7;

const MOIS = [
  ["JANVIER", 1], ["FEVRIER", 2], ["MARS", 3], ["AVRIL", 4], ["MAI", 5],
  ["JUIN", 6], ["JUILLET", 7], ["AOUT", 8], ["SEPTEMBRE", 9], ["OCTOBRE", 10],
  ["NOVEMBRE", 11], ["DECEMBRE", 12],
];

// ---------- Outils ----------

const sansAccent = (t) =>
  String(t ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().trim();

const cleTexte = (x) => sansAccent(x).replace(/\s+/g, " ");

function parseCSV(texte) {
  if (texte.charCodeAt(0) === 0xfeff) texte = texte.slice(1);
  const lignes = [];
  let ligne = [], cellule = "", guillemets = false;
  for (let i = 0; i < texte.length; i++) {
    const c = texte[i];
    if (guillemets) {
      if (c === '"') {
        if (texte[i + 1] === '"') { cellule += '"'; i++; } else guillemets = false;
      } else cellule += c;
    } else if (c === '"') guillemets = true;
    else if (c === ",") { ligne.push(cellule); cellule = ""; }
    else if (c === "\n") { ligne.push(cellule); lignes.push(ligne); ligne = []; cellule = ""; }
    else if (c !== "\r") cellule += c;
  }
  if (cellule !== "" || ligne.length) { ligne.push(cellule); lignes.push(ligne); }
  return lignes;
}

function parseDate(v) {
  const s = String(v ?? "").trim();
  if (!s || ["nan", "nat", "none"].includes(s.toLowerCase())) return null;
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3]);
  m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/);   // jour/mois/année
  if (m) {
    let a = +m[3];
    if (a < 100) a += 2000;
    return Date.UTC(a, +m[2] - 1, +m[1]);
  }
  return null;
}

function formatDate(ms) {
  if (ms === null) return "";
  const d = new Date(ms);
  return `${String(d.getUTCDate()).padStart(2, "0")}/${String(d.getUTCMonth() + 1).padStart(2, "0")}/${d.getUTCFullYear()}`;
}

function debutMoisSuivant(period) {
  if (!period) return null;
  const texte = sansAccent(period);
  const a = texte.match(/\b(20\d{2})\b/);
  const m = MOIS.find(([nom]) => texte.includes(nom));
  if (!a || !m) return null;
  const annee = +a[1], mois = m[1];
  return mois === 12 ? Date.UTC(annee + 1, 0, 1) : Date.UTC(annee, mois, 1);
}

// ---------- Lecture d'une feuille ----------

async function lireFeuille(id, gid, colonnes, minimum, nom) {
  const url = `https://docs.google.com/spreadsheets/d/${encodeURIComponent(id)}/export?format=csv&gid=${encodeURIComponent(gid)}`;
  const r = await fetch(url, { redirect: "follow" });
  const type = r.headers.get("content-type") || "";
  if ([401, 403].includes(r.status) || type.includes("text/html")) {
    throw new Error(`Accès refusé (${nom}) : vérifier le partage du classeur`);
  }
  if (!r.ok) throw new Error(`Réponse HTTP ${r.status} (${nom})`);

  const lignes = parseCSV(await r.text());
  if (!lignes.length) throw new Error(`Feuille vide (${nom})`);
  const largeur = lignes[0].length;
  if (largeur < minimum) {
    throw new Error(`${nom} : ${largeur} colonnes, ${minimum} minimum attendues`);
  }
  const n = Math.min(largeur, colonnes.length);
  const data = lignes
    .slice(1)
    .filter((l) => l.some((c) => String(c).trim() !== ""))
    .map((l) => {
      const o = {};
      for (let i = 0; i < n; i++) o[colonnes[i]] = String(l[i] ?? "").trim();
      return o;
    });
  if (!data.length) throw new Error(`Aucune ligne (${nom})`);
  return data;
}

// ---------- Calcul des indicateurs ----------

function calculerLigne(r) {
  const dSoum = parseDate(r.date_soumission);
  const dAut = parseDate(r.date_autorisation);
  const estDistrict = sansAccent(r.facility).includes("DISTRICT");
  const base = debutMoisSuivant(r.period);
  const limite =
    base === null ? null : base + ((estDistrict ? JOUR_LIMITE_DISTRICT : JOUR_LIMITE_AUTRES) - 1) * JOUR;

  return {
    region: r.region || "",
    code: r.code || "",
    facility: r.facility || "",
    district: r.district || "",
    program: r.program || "",
    period: r.period || "",
    statut: r.statut || "",
    date_soumission: formatDate(dSoum),
    date_autorisation: formatDate(dAut),
    date_limite: formatDate(limite),
    completude: dSoum !== null ? 1 : 0,
    promptitude: dAut !== null && limite !== null && dAut <= limite ? 1 : 0,
    type_etablissement: estDistrict ? "District" : "Autres établissements",
    presence: "",
  };
}

// ---------- Rapprochement avec la liste des sites attendus ----------

function rapprocher(lignes, sites) {
  const cle = (d, f) => `${cleTexte(d)}|${cleTexte(f)}`;

  const attendus = new Map();
  for (const s of sites) {
    if (!s.facility) continue;
    const k = cle(s.district, s.facility);
    if (!attendus.has(k)) attendus.set(k, s);
  }

  const presents = [];
  let horsListe = 0;
  for (const l of lignes) {
    l._cle = cle(l.district, l.facility);
    if (attendus.has(l._cle)) presents.push(l); else horsListe++;
  }
  if (!presents.length) {
    throw new Error("Aucun site reçu ne correspond à la liste des sites attendus");
  }
  presents.forEach((l) => { l.presence = "Ligne reçue"; });

  const periodes = [...new Set(lignes.map((l) => l.period).filter((p) => p && debutMoisSuivant(p) !== null))];
  const existants = new Set(presents.map((l) => `${l._cle}||${l.period}`));

  const regionParDistrict = new Map();
  for (const l of lignes) {
    const k = cleTexte(l.district);
    if (l.district && l.region && !regionParDistrict.has(k)) regionParDistrict.set(k, l.region);
  }

  const resultat = presents.map(({ _cle, ...reste }) => reste);
  let absents = 0;
  for (const [k, s] of attendus) {
    const region = s.region || regionParDistrict.get(cleTexte(s.district)) || "";
    for (const p of periodes) {
      if (existants.has(`${k}||${p}`)) continue;
      const ligne = calculerLigne({
        region, district: s.district, facility: s.facility, period: p, statut: "NON TRANSMIS",
      });
      ligne.presence = "Aucune ligne reçue";
      resultat.push(ligne);
      absents++;
    }
  }
  return { resultat, stats: { sites: attendus.size, periodes: periodes.length, absents, horsListe } };
}

// ---------- Point d'entrée ----------

exports.handler = async () => {
  try {
    const id = process.env.GSHEET_ID;
    if (!id) throw new Error("Variable GSHEET_ID non définie");

    const brut = await lireFeuille(
      id, process.env.GSHEET_GID || "0", COLONNES_SHEET, COLONNES_MINIMUM, "données"
    );
    let rows = brut.map(calculerLigne);
    let stats = null;

    const idSites = process.env.SITES_SHEET_ID;
    if (idSites) {
      const sites = await lireFeuille(
        idSites, process.env.SITES_GSHEET_GID || "0",
        COLONNES_SITES, COLONNES_SITES_MINIMUM, "liste des sites"
      );
      const r = rapprocher(rows, sites);
      rows = r.resultat;
      stats = r.stats;
    }

    const ordre = (p) => { const b = debutMoisSuivant(p); return b === null ? Number.MAX_SAFE_INTEGER : b; };
    const periodes = [...new Set(rows.map((l) => l.period).filter(Boolean))].sort((a, b) => ordre(a) - ordre(b));
    const lisibles = periodes.filter((p) => debutMoisSuivant(p) !== null);

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "private, max-age=60",
      },
      body: JSON.stringify({
        genere: new Date().toISOString(),
        periodes,
        derniere: lisibles.length ? lisibles[lisibles.length - 1] : (periodes[periodes.length - 1] || ""),
        stats,
        rows,
      }),
    };
  } catch (e) {
    // Le détail reste dans les journaux Netlify ; le navigateur ne reçoit aucun indice sur la source.
    console.error("Erreur données :", e.message);
    return {
      statusCode: 502,
      headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
      body: JSON.stringify({ erreur: "Les données sont momentanément indisponibles. Réessayez dans quelques instants." }),
    };
  }
};

exports._interne = { parseCSV, parseDate, debutMoisSuivant, rapprocher, calculerLigne };
